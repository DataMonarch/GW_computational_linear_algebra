import edu.gwu.lintool.*;

public class TestLinToolClasspath {

    public static void main (String[] argv)
    {
	LinTest.testClasspath ();
    }

}

